import React from "react";

function Customer(){
    return(
        <>
        <section id="customer">
            <div className="customer-Main">
<h1>This is customer page</h1>
            </div>
        </section>
        
        </>
    )
}

export{Customer}