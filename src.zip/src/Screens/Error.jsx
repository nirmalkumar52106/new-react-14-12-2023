import React from "react"

function Error() {
    return (
        <>
            <div>
                <h1>this is error page</h1>
            </div>

        </>
    )
}

export { Error }