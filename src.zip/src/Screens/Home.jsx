import React from "react";
import { Footerpge } from "../Homecomponents/Footer";
import { Navbar } from "../Homecomponents/Navbar";
import { Products } from "../Homecomponents/Products/Item";

function Home(){
    return(
        <>
        <Navbar/>
        <Products/>
        <Footerpge/>
        
        </>
    )
}

export{Home}