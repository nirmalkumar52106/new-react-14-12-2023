// import React from "react";
// import { useParams } from "react-router-dom";

// function Mycomponent(){
//     let {email}=useParams()
//     return(
//         <>
//         <h1>this is {email} example</h1>
//         </>
//     )
// }

// export{Mycomponent}